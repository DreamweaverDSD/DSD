package com.example.dsd_android;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class DiscardDataActivity extends AppCompatActivity {

    Button button_discarddata_BackToData;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_discarddata);
        button_discarddata_BackToData=findViewById(R.id.Button_discarddata_BackToData);
        button_discarddata_BackToData.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }
}
