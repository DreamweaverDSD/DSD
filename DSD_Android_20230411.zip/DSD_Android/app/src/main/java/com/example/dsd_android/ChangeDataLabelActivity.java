package com.example.dsd_android;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class ChangeDataLabelActivity extends AppCompatActivity {

    Button button_changedatalabel_BackToData;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_changedatalabel);
        button_changedatalabel_BackToData=findViewById(R.id.Button_changedatalabel_BackToData);
        button_changedatalabel_BackToData.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(ChangeDataLabelActivity.this,DataActivity.class);
                startActivity(intent);
            }
        });
    }
}
